#include "Obstacle.h"

class Truck :public Obstacle
{
public:
	Truck(int, int, int);
};