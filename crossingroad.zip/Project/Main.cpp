#include "Obstacle.h"
#include "point.h"
#include "Car.h"
#include "Truck.h"
#include "Dog.h"
#include "Snowman.h"
using namespace std;

int OFFSET_X = 10, OFFSET_Y = 10;

void showConsoleCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag;
	SetConsoleCursorInfo(out, &cursorInfo);
}
void fixConsoleWindow()
{
	HWND hwnd = GetConsoleWindow();
	RECT rect = {50, 50, 1500, 800 };
	MoveWindow(hwnd, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, TRUE);
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);

	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);
	SetWindowLong(consoleWindow, GWL_STYLE, style);

	showConsoleCursor(false);
	
}
void TextColor(int color)
{
	HANDLE mau;
	mau = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(mau, color);
}
//void goToXY(int x, int y)
//{
//	COORD coord;
//
//	coord.X = x;
//	coord.Y = y;
//
//	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
//}
//
//
//class Wall
//{
//
//};
//
//class point
//{
//	COORD c;
//	char ch;
//public:
//	point()
//	{
//		c.X = 0;
//		c.Y = 0;
//		ch = 0;
//	};
//	point(COORD c, char ch)
//	{
//		this->c = c;
//		this->ch = ch;
//	};
//	void increaseX()
//	{
//		this->c.X++;
//	}
//	void increaseY()
//	{
//		this->c.Y++;
//	}
//	COORD getCoord()
//	{
//		return this->c;
//	}
//	//getter
//	int cX()
//	{
//		return this->c.X;
//	}
//	int cY()
//	{
//		return this->c.Y;
//	}
//	char getChar()
//	{
//		return this->ch;
//	}
//};
//
//
//class Car
//{
//	deque<point> p;
//	string a = " _.-.___\\__";
//	string b = "|  _      _`-.";
//	string c = "'-(_)----(_)--`";
//	int size;
//public:
//	Car()
//	{
//		for (int i = 0; i < 3; i++)
//		{
//			COORD temp;
//			temp.Y = OFFSET_Y + i;
//			if (i == 0)
//			{
//				for (int j = 0; j < 11; j++)
//				{
//					temp.X = OFFSET_X + j;
//					point tempP(temp, a[j]);
//					p.push_back(tempP);
//				}
//			}
//			else if (i == 1)
//			{
//				for (int j = 0; j < 15; j++)
//				{
//					temp.X = OFFSET_X + j;
//					point tempP(temp, b[j]);
//					p.push_back(tempP);
//				}
//			}
//			else if (i == 2)
//			{
//				for (int j = 0; j < 16; j++)
//				{
//					temp.X = OFFSET_X + j;
//					point tempP(temp, c[j]);
//					p.push_back(tempP);
//				}
//			}
//		}
//		size = p.size();
//	}
//	Car(const Car& temp)
//	{
//		*this = temp;
//	}
//	int getSize()
//	{
//		return this->size;
//	}
//	Car& operator++()
//	{
//		for (int i = 0; i < p.size(); i++)
//		{
//			p[i].increaseX();
//		}
//		return *this;
//	}
//	Car operator++(int x)
//	{
//		Car temp(*this);
//		++(*this);
//		return temp;
//	}
//	bool isColide(const COORD& coord)
//	{
//		for (int i = 0; i < p.size(); i++)
//		{
//			if (p[i].cX() == coord.X && p[i].cY() == coord.Y)
//			{
//				return true;
//			}
//		}
//		return false;
//	}
//	friend ostream& operator<<(ostream& out, Car& car)
//	{
//		for (int i = 0; i < car.p.size(); i++)
//		{
//			goToXY(car.p[i].cX(), car.p[i].cY());
//			cout << car.p[i].getChar();
//		}
//		return out;
//	}
//	void undrawCar1()
//	{
//		goToXY(p[0].cX(), p[0].cY());
//		cout << " ";
//		goToXY(p[11].cX(), p[11].cY());
//		cout << " ";
//		goToXY(p[26].cX(), p[26].cY());
//		cout << " ";
//	}
//	void undrawCar2()
//	{
//		for (int i = 0; i < p.size(); i++)
//		{
//			goToXY(p[i].cX(), p[i].cY());
//			cout <<" ";
//		}
//	}
//	COORD getCoord()
//	{
//		return p[0].getCoord();
//	}
//};

void ThreadT1()
{
	deque<Car> c;
	deque<Truck> t;
	deque<Dog> d;
	//deque<Snowman> s;
	while (1)
	{
		//Sleep(15/15);
		//Car
		if (c.size() == 0)
		{
			c.push_back(Car(10, 10, 1));
		}
		else if (c.size() < 4 && c[c.size() - 1].getDistanceFromStart() > c[c.size() - 1].getDistance())
			c.push_back(Car(10, 10, 1));
		for (int i = 0; i < c.size(); i++) {
			c[i].undrawBack();
			c[i].move();
			c[i].draw();
		}
		if (c[0].reachEndPoint(130)) {
			c[0].undraw();
			c.pop_front();
		}

		//Truck
		if (t.size() == 0)
		{
			t.push_back(Truck(130, 15, -1));
		}
		else if (t.size() < 3 && t[t.size() - 1].getDistanceFromStart() > t[t.size() - 1].getDistance())
			t.push_back(Truck(130, 15, -1));
		for (int i = 0; i < t.size(); i++) {
			t[i].undrawBack();
			t[i].move();
			t[i].draw();
		}
		if (t[0].reachEndPoint(50)) {
			t[0].undraw();
			t.pop_front();
		}
		//Dog
		if (d.size() == 0)
		{
			d.push_back(Dog(10, 20, 1));
		}
		else if (d.size() < 4 && d[d.size() - 1].getDistanceFromStart() > d[d.size() - 1].getDistance())
			d.push_back(Dog(10, 20, 1));
		for (int i = 0; i < d.size(); i++) {
			d[i].undrawBack();
			d[i].move();
			d[i].draw();
		}
		if (d[0].reachEndPoint(130)) {
			d[0].undraw();
			d.pop_front();
		}

		//Snowman
		/*if (s.size() == 0)
		{
			s.push_back(Snowman(180, 25, -1));
		}
		else if (s.size() < 3 && s[s.size() - 1].getDistanceFromStart() > s[s.size() - 1].getDistance())
			s.push_back(Snowman(180, 25, -1));
		for (int i = 0; i < s.size(); i++) {
			s[i].undrawBack();
			s[i].move();
			s[i].draw();
		}
		if (s[0].reachEndPoint(10)) {
			s[0].undraw();
			s.pop_front();
		}*/
	}

}

int main()
{
	fixConsoleWindow();
	
	thread t1(ThreadT1);
	while (1)
	{

	}
	
	return 0;
}