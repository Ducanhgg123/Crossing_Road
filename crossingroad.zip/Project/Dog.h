#include "Obstacle.h"

class Dog :public Obstacle
{
public:
	Dog(int, int, int);
};