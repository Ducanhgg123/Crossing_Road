#include "Obstacle.h"

class Car :public Obstacle
{
public:
	Car(int, int, int);
};