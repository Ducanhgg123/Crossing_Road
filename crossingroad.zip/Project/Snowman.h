#include "Obstacle.h"

class Snowman :public Obstacle
{
public:
	Snowman(int, int, int);
};